package web;

import java.util.HashMap;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import job.ScanningJob;
import resultretriever.ResultRetrieverImpl;

public class WebService {
	

	private ResultRetrieverImpl resultRetrieverImpl;
	private BlockingQueue<ScanningJob> jobs;
	private ExecutorService webThreadPool = Executors.newCachedThreadPool();
	private CompletionService<HashMap<String, Integer>> service = new ExecutorCompletionService<HashMap<String,Integer>>(webThreadPool);
	
	public void submitScanJob(Callable<HashMap<String, Integer>> job) {
		Future<HashMap<String, Integer>> future = webThreadPool.submit(job);
		resultRetrieverImpl.addCorpusResult(future);
	}
	
	public WebService(ResultRetrieverImpl resultRetrieverImpl, BlockingQueue<ScanningJob> jobs) {
		this.resultRetrieverImpl = resultRetrieverImpl;
		this.jobs = jobs;
	}

	public void shutdownWebThreadPool() {
		webThreadPool.shutdown();
	}

}

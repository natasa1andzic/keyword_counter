package web;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.sun.jdi.connect.spi.Connection;

import job.JobDispatcher;
import job.ScanType;
import job.ScanningJob;

public class WebJob implements Callable<HashMap<String, Integer>>, ScanningJob {

	private HashMap<String, Integer> wordResultHashMap = new HashMap<String, Integer>();
	private Document webPageDocument = null;
	private int hops;
	private BlockingQueue<ScanningJob> jobs;

	private Properties configProperties = new Properties();
	private InputStream inputStream = null;

	// web stranica od koje krece obilazenje
	private String parametarString;

	public WebJob(String parametarString) {
		this.parametarString = parametarString;
	}

	public WebJob(String parametarString, int hops, BlockingQueue<ScanningJob> jobs) {
		this.parametarString = parametarString;
		this.hops = hops;
		this.jobs = jobs;
	}

	@Override
	public ScanType geType() {
		return ScanType.WEB;
	}

	@Override
	public HashMap<String, Integer> call() throws Exception {

		try {
			inputStream = new FileInputStream("app.properties");
			configProperties.load(inputStream);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			webPageDocument = Jsoup.connect(parametarString).timeout(10000).get();

			System.out.println("Konektovali smo se na stranicu\n");
			org.jsoup.nodes.Element body = webPageDocument.body();
			Elements links = webPageDocument.select("a[href]");
			System.out.println("Ukupan broj linkova na ovoj stranici je: " + links.size());
			String allTextString = body.text();

			String[] wordStrings = allTextString.split(" ");
			for (String word : wordStrings) {
				boolean isKeyword = false;
				String keywords = configProperties.getProperty("keywords");
				String[] keys = keywords.split(",");
				for (String key : keys) {
					isKeyword = key.equals(word);
					if (isKeyword)
						if (wordResultHashMap.containsKey(word))
							wordResultHashMap.put(word, wordResultHashMap.get(word) + 1);
						else {
							wordResultHashMap.put(word, 1);
						}
				}
			}

			if (hops > 0) {
				for (Element element : links) {
					WebJob newWebJob = new WebJob(element.absUrl("href"), hops - 1, jobs);
					System.out
							.println("Hash mapa za " + element.absUrl("href").toString() + " je " + wordResultHashMap);
					jobs.add(newWebJob);
				}
			}

		} catch (MalformedURLException e) {
			System.err.println("Ne valja url");
		}

		System.out.println(webPageDocument.title() + (wordResultHashMap));
		return wordResultHashMap;
	}

}

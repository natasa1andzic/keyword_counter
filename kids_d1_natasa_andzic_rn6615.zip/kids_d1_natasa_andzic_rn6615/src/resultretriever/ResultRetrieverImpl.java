package resultretriever;

import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Future;

public class ResultRetrieverImpl {
	
	private HashMap<String, Integer> fileResults;
	private HashMap<String, Integer> webResults;
	
	public HashMap<String, Integer> getMapForDirectory(String directoryString){
		//Future<HashMap<String, Integer>> future = fileResults.get(directoryString);
		return null;
	}
	
	public HashMap<String, Integer> queryMapForDirectory(String directoryString) {
		return new HashMap<String, Integer>();
	}
	
	public void clearFileSummary() {
		fileResults.clear();
	}
	
	public void clearWebSummary() {
		webResults.clear();
	}

	public void addCorpusResult(Future<HashMap<String, Integer>> future) {		
	}

}

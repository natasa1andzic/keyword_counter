package job;


public interface ScanningJob {
	
	ScanType geType();

}

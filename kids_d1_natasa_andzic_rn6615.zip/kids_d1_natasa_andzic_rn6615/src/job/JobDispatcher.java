package job;

import java.util.concurrent.BlockingQueue;

import file.FileJob;
import file.FileService;
import web.WebJob;
import web.WebService;

/**
 * @author n.andzic Pojedinacna nit koja cita job queue. Ceka pojavljivanje
 *         novog posla, i onda ga delegira odgovarajucem threadpool sistemu. Ova
 *         nit treba da se blokira ako nema stavki u queue-u.
 */

public class JobDispatcher implements Runnable {

	private BlockingQueue<ScanningJob> jobs;
	private FileService fileService;
	private WebService webService;

	public JobDispatcher(BlockingQueue<ScanningJob> jobs, WebService webService, FileService fileService) {
		this.jobs = jobs;
		this.webService = webService;
		this.fileService = fileService;
	}

	@Override
	public void run() {
		while (true) {
			ScanningJob job;
			try {	
				job = jobs.take();
				if (job.geType().equals(ScanType.STOP)) {
					fileService.shutdownFileThreadPool();
					webService.shutdownWebThreadPool();
					break;
				}
				else if (job.geType().equals(ScanType.FILE)) {
					fileService.submitScanJob((FileJob) job);
				} else if (job.geType().equals(ScanType.WEB)) {
					webService.submitScanJob((WebJob) job);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}

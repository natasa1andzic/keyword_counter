package job;

public class StopJob implements ScanningJob {
		
	@Override
	public ScanType geType() {
		return ScanType.STOP;
	}

}

package job;

public enum ScanType {
	WEB, FILE, STOP

}

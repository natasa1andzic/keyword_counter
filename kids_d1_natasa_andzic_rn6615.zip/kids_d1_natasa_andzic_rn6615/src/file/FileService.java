package file;

import java.util.HashMap;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;
import java.util.concurrent.RecursiveTask;

import resultretriever.ResultRetrieverImpl;

public class FileService {
	
	private ForkJoinPool forkJoinPool;
	private ResultRetrieverImpl resultRetrieverImpl;
	
	public FileService(ResultRetrieverImpl result) {
		forkJoinPool = ForkJoinPool.commonPool();
		this.resultRetrieverImpl = result;
	}
	
	public void submitScanJob(RecursiveTask<HashMap<String, Integer>> job) {
		Future<HashMap<String, Integer>> future= forkJoinPool.submit(job);
		//jel treba ovde HashMap<String, Integer> map = future.get(); ????
		resultRetrieverImpl.addCorpusResult(future);
	}
	
	public void shutdownFileThreadPool( ) {
		forkJoinPool.shutdown();
	}

}

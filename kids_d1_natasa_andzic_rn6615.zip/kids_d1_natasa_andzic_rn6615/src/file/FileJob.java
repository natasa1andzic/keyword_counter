package file;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.RecursiveTask;

import job.ScanType;
import job.ScanningJob;

public class FileJob extends RecursiveTask<HashMap<String, Integer>> implements ScanningJob {

	private File currentDirectory;
	private Properties configProperties = new Properties();
	private InputStream inputStream = null;

	private List<File> filesForSearch;
	private File[] filesArray;

	private HashMap<String, Integer> remainingResult = new HashMap<String, Integer>();
	private HashMap<String, Integer> mergedResult = new HashMap<String, Integer>();

	public FileJob(File currentDirectory) {
		this.currentDirectory = currentDirectory;
	}

	public FileJob(List<File> filesForSearch) {
		this.filesForSearch = filesForSearch;
	}

	public List<File> getFilesFromCurrentDirectory(File currentDirectory) {
		filesArray = currentDirectory.listFiles();
		filesForSearch = Arrays.asList(filesArray);
		return filesForSearch;
	}

	@Override
	public ScanType geType() {
		return ScanType.FILE;
	}

	@Override
	protected HashMap<String, Integer> compute() {

		try {
			inputStream = new FileInputStream("app.properties");
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}

		try {
			configProperties.load(inputStream);
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		Long limit = Long.parseLong(configProperties.getProperty("file_scanning_size_limit"));
		LinkedList<File> firstTaskList = new LinkedList<File>();
		ConcurrentHashMap<String, Integer> wordResult = new ConcurrentHashMap<String, Integer>();

		int sum = 0, index = 0;
		boolean isBroken = false;
		filesForSearch = getFilesFromCurrentDirectory(currentDirectory);
		for (File file : filesForSearch) {
			sum += file.length();
			index++;
			firstTaskList.add(file);
			if (sum >= limit) {
				isBroken = true;
				break;
			}
		}

		FileJob remainingTaskJob = null;

		if (isBroken == true) {
			filesForSearch.subList(0, index).clear();
			remainingTaskJob = new FileJob(filesForSearch);
			remainingTaskJob.fork();
		}

		if (firstTaskList.size() != 0) {
			for (File file : firstTaskList) {
				BufferedReader reader;
				try {
					reader = new BufferedReader(new FileReader(file));
					while (reader.ready()) {
						String lineString = reader.readLine();
						String[] words = lineString.split(" ");
						for (String word : words) {
							boolean isKeyword = false;
							String keywords = configProperties.getProperty("keywords");
							String[] keys = keywords.split(",");
							for (String key : keys) {
								isKeyword = key.equals(word);
								if (isKeyword)
									if (wordResult.containsKey(word))
										wordResult.put(word, wordResult.get(word) + 1);
									else {
										wordResult.put(word, 1);
									}
							}
						}
					}
				} catch (FileNotFoundException e) {
					System.err.println("Datoteka " +file.getName()+  "ne valja");
					e.printStackTrace();
				} catch (IOException e) {
					System.err.println("Datoteka " +file.getName()+  "ne valja");

					e.printStackTrace();
				}

				if (remainingTaskJob != null) {
					remainingResult = (HashMap<String, Integer>) remainingTaskJob.join();
				}
			}

		}
		mergedResult.putAll(wordResult);
		mergedResult.putAll(remainingResult);
		System.out.println("130. FJ-> Merge-ovani rezultat za corpus je: " + mergedResult);
		return mergedResult;

	}
}
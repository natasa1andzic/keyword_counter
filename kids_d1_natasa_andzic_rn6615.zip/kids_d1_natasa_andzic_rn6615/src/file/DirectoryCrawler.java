package file;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.Queue;
import java.util.concurrent.BlockingQueue;

import job.ScanningJob;

public class DirectoryCrawler {

	private BlockingQueue<ScanningJob> jobs;

	private Properties configProperties = new Properties();
	private InputStream inputStream = null;

	private String folderPrefix;
	private File mainDirectory;
	public static final String poison = "poison";

	private Queue<File> directoriesForSearch = new LinkedList<>();

	private List<File> filesForSearch = new ArrayList<File>();

	private HashMap<File, Long> lastModifiedHashMap = new HashMap<File, Long>();

	public DirectoryCrawler(BlockingQueue<ScanningJob> jobs) {
		this.jobs = jobs;
	}

	public synchronized void submitJob(String parametarString) {

		try {
			inputStream = new FileInputStream("app.properties");
			configProperties.load(inputStream);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		folderPrefix = configProperties.getProperty("file_corpus_prefix");

		mainDirectory = new File(parametarString);
		
		if(mainDirectory.getName().equals(poison)) 
			return;
		 

		if (!mainDirectory.isDirectory()) {
			System.out.println("60. DC-> " + mainDirectory + " nije direktorijum, unesite dobar parametar");
			return;
		} else {
			System.out.println("63. DC-> " + mainDirectory + " jeste direktorijum, idemo dalje");
		}

		directoriesForSearch.add(mainDirectory);
		while (!directoriesForSearch.isEmpty()) {
			File currentFile = directoriesForSearch.poll();
			if (currentFile.isDirectory() && currentFile.getName().startsWith(folderPrefix)) {
				System.out.println("70. DC-> " + currentFile
						+ " je folder i pocinje sa zadatim prefiksom, pa fajlove iz njega dodajemo u listu");
				File[] txtFilesInCurrentDirectoryFiles = currentFile.listFiles();
				for (File file : txtFilesInCurrentDirectoryFiles) {
					boolean isModified = false;
					Long lastModifiedForCurrentFileLong = lastModifiedHashMap.getOrDefault(file, (long) 0);
					if (file.lastModified() != lastModifiedForCurrentFileLong)
						isModified = true;
					lastModifiedHashMap.put(file, file.lastModified());

					if (isModified) {
						FileJob newFileJob = new FileJob(currentFile);
						jobs.add(newFileJob);
						filesForSearch.add(file);
						System.out.println("84. DC-> " + file.getName() + " je dodat u listu za pretrazivanje");
						isModified = false;
					}
					
					else {
						System.out.println("89. DC-> Fajl " +file.getName()+ " nije izmenjen, pa ga ne pretrazujemo\n");
					}
				}
			}

			else if (currentFile.isDirectory() && !(currentFile.getName().startsWith(folderPrefix))) {
				File[] childFiles = currentFile.listFiles();
				for (File file : childFiles) {
					if (file.isDirectory()) {
						directoriesForSearch.add(file);
						System.out.println("99. DC-> Dodali smo " + file.getName() + " u red foldera");
					}
				}
			}

			Long millis = Long.parseLong(configProperties.getProperty("dir_crawler_sleep_time"));

			try {
				Thread.sleep(millis);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public List<File> getFilesForSearch() {
		return filesForSearch;
	}

}

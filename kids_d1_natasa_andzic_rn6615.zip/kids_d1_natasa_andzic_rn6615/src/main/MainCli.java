package main;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;

import file.DirectoryCrawler;
import file.FileService;
import job.JobDispatcher;
import job.ScanningJob;
import job.StopJob;
import resultretriever.ResultRetrieverImpl;
import web.WebJob;
import web.WebService;

/**
 * @author n.andzic
 * 
 * Pojedinacna nit koja pri startovanju ucitava podesavanja iz properties datoteke.
 * Potom se ocekuje komanda od korisnika. 
 * 
 * Komanda ad sluzi da navede novi direktorijum za obilazenje. 
 * Doda se stavka u listu direktorijuma koje DirectoryCrawler obilazi.
 * 
 * Komanda aw sluzi da navede novu polaznu stranicu za obilazenje preko weba. 
 * Ova komanda kreira novi posao za web i stavlja ga direktno u JobQueue
 */


public class MainCli {
	
	public static void main(String[] args) {
		
		ExecutorService mainPool = Executors.newFixedThreadPool(5);
		
		BlockingQueue<ScanningJob> jobs = new LinkedBlockingQueue<>();
		DirectoryCrawler directoryCrawler = new DirectoryCrawler(jobs);
		ResultRetrieverImpl resultRetrieverImpl = new ResultRetrieverImpl();
		Properties configProperties = new Properties();
		InputStream inputStream = null;
		int hops = 0;
		
		WebService webService = new WebService(resultRetrieverImpl, jobs);
		FileService fileService = new FileService(resultRetrieverImpl);
		
		mainPool.submit(new JobDispatcher(jobs, webService, fileService));
		
		try {
			inputStream = new FileInputStream("app.properties");
			configProperties.load(inputStream);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		hops = Integer.parseInt(configProperties.getProperty("hop_count"));

		Scanner scanner = new Scanner(System.in);
		System.out.println("Unesite komandu: ");
		
		while(true) {
			String userInputString = scanner.nextLine();
			
			/**
			 * Ako je argument na komandnoj liniji "ad ...":
			 * drugi parametar je folder za skeniranje koji se prosledjuje DirectoryCrawler komponenti. 
			 */
			
			if(userInputString.startsWith("ad ")) {
				System.out.println("MainCli -> Ovo je komanda za unos direktorijuma za skeniranje");
				String parametarString = userInputString.substring(3);
				if(parametarString.equals("poison"))
					break;
				System.out.println("Folder za pretrazivanje je " +parametarString);
				directoryCrawler.submitJob(parametarString);
			}
			
			/**
			 * Ako je argument na komandnoj liniji "aw ...":
			 * drugi parametar je url za skeniranje od kog treba da krene obilazenje i pretraga.
			 * Ova komanda kreira novi job za web i stavlja ga direktno u job queue. 
			 */
			
			else if(userInputString.startsWith("aw ")) {
				System.out.println("MainCli -> Ovo je komanda za unos web stranice od koje se krece obilazenje");
				String parametarString = userInputString.substring(3);
				jobs.add(new WebJob(parametarString, hops, jobs));
			}
			
			/**
			 * Ako je argument na komandnoj liniji "get ...":
			 * drugi parametar je direktorijum, dohvati rezultat iz ResultRetriever komponente 
			 * i ispisi ga na konzoli. Kao argument se dohvata upit(2.5). 
			 * Ova komanda blokira dalji rad dok ne dobije rezultat.
			 */
			
			else if(userInputString.startsWith("get ")) {
				System.out.println("Ovo je blokirajuca komanda za folder, ispisuje rezultat za dati argument");
				String parametarString = userInputString.substring(4);
				System.out.println(parametarString);
				resultRetrieverImpl.getMapForDirectory(parametarString);
			}
			
			/**
			 * Ako je argument na komandnoj liniji "query...":
			 * drugi parametar je direktorijum, dohvati rezultat iz ResultRetriever komponente 
			 * i ispisi ga na konzoli. Kao argument se dohvata upit(2.5). 
			 * Ova komanda ne blokira dalji rad, vec samo ispisuje poruku 
			 * ako rezultati nisu dostupni ili ako posao za taj upit jos nije zapocet.
			 */
			
			else if(userInputString.startsWith("query ")) {
				System.out.println("Ovo je neblokirajuca komanda za folder, ispisuje rezultat za dati argument");
				String parametarString = userInputString.substring(5);
				System.out.println(parametarString);
				resultRetrieverImpl.queryMapForDirectory(parametarString);
			}
			
			/**
			 * Ako je argument na komandnoj liniji "cfs":
			 * Clear file summary - javi ResultRetriever komponenti da obrise rezultat za fajlove, 
			 * ako ga ima sacuvanog.
			 */
			
			else if(userInputString.equals("cfs")) {
				System.out.println("Ovo je komanda za brisanje rezultata za fajlove");
				resultRetrieverImpl.clearFileSummary();
			}
			
			/**
			 * Ako je argument na komandnoj liniji "cws":
			 * Clear web summary - javi ResultRetriever komponenti da obrise rezultat za web,
			 * ako ga ima sacuvanog.
			 */
			
			else if(userInputString.equals("cws")) {
				System.out.println("Ovo je komanda za brisanje rezultata za web");
				resultRetrieverImpl.clearWebSummary();
			}
			
			/**
			 * Ako je argument na komandnoj liniji "stop":
			 * ugasi aplikaciju, zaustavi sve threadpool-ove i javi svim nitima da zavrse sa radom.
			 * Ne koristiti nasilna prekidanja/interrupt/daemon za ovu komandu.
			 */
			
			else if(userInputString.equals("stop") ) {
				System.out.println("Ovo je komanda za gasenje aplikacije");
				jobs.add(new StopJob());
				directoryCrawler.submitJob(DirectoryCrawler.poison);
				mainPool.shutdown();
				return;
				
			}
			
			else {
				//Greska br. 1
				System.out.println("Uneli ste nepostojecu komandu ili pogresan broj karaktera, pokusajte ponovo");
			}
				
		}
		
		
	}
	
	

}
